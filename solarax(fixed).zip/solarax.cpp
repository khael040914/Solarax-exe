#include <windows.h>
#include <algorithm>
#include <cmath>
#include <iostream>

// Function pointer typedefs
typedef BOOL(WINAPI* BitBlt_t)(HDC, int, int, int, int, HDC, int, int, DWORD);
typedef BOOL(WINAPI* GetCursorPos_t)(LPPOINT);
typedef BOOL(WINAPI* PatBlt_t)(HDC, int, int, int, int, DWORD);
typedef int(WINAPI* GetSystemMetrics_t)(int);
typedef HDC(WINAPI* GetDC_t)(HWND);
typedef int(WINAPI* ReleaseDC_t)(HWND, HDC);
typedef BOOL(WINAPI* SetCursorPos_t)(int, int);
typedef BOOL(WINAPI* DrawIcon_t)(HDC, int, int, HICON);
typedef HICON(WINAPI* LoadIcon_t)(HINSTANCE, LPCSTR);
typedef BOOL(WINAPI* PolyBezier_t)(HDC, const POINT*, DWORD);
typedef HPEN(WINAPI* CreatePen_t)(int, int, COLORREF);
typedef HGDIOBJ(WINAPI* SelectObject_t)(HDC, HGDIOBJ);
typedef BOOL(WINAPI* DeleteObject_t)(HGDIOBJ);
typedef BOOL(WINAPI* InvalidateRect_t)(HWND, CONST RECT*, BOOL);
typedef int(WINAPI* MessageBoxW_t)(HWND, LPCWSTR, LPCWSTR, UINT);
typedef MMRESULT(WINAPI* WaveOutOpen_t)(LPHWAVEOUT, UINT, LPCWAVEFORMATEX, DWORD_PTR, DWORD_PTR, DWORD);
typedef MMRESULT(WINAPI* WaveOutPrepareHeader_t)(HWAVEOUT, LPWAVEHDR, UINT);
typedef MMRESULT(WINAPI* WaveOutWrite_t)(HWAVEOUT, LPWAVEHDR, UINT);
typedef MMRESULT(WINAPI* WaveOutClose_t)(HWAVEOUT);
typedef MMRESULT(WINAPI* WaveOutUnprepareHeader_t)(HWAVEOUT, LPWAVEHDR, UINT);
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
} _RGBQUAD, * PRGBQUAD;

int red, green, blue;
bool ifcolorblue = false, ifblue = false;

COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
    return RGB(0, 0, 0);
}
DWORD WINAPI soundThread(LPVOID lpParam) {
    HINSTANCE hWinMM = LoadLibraryA("winmm.dll");
    if (!hWinMM) return 0;

    // Get function pointers
    WaveOutOpen_t myWaveOutOpen = (WaveOutOpen_t)GetProcAddress(hWinMM, "waveOutOpen");
    WaveOutPrepareHeader_t myWaveOutPrepareHeader = (WaveOutPrepareHeader_t)GetProcAddress(hWinMM, "waveOutPrepareHeader");
    WaveOutWrite_t myWaveOutWrite = (WaveOutWrite_t)GetProcAddress(hWinMM, "waveOutWrite");
    WaveOutClose_t myWaveOutClose = (WaveOutClose_t)GetProcAddress(hWinMM, "waveOutClose");
    WaveOutUnprepareHeader_t myWaveOutUnprepareHeader = (WaveOutUnprepareHeader_t)GetProcAddress(hWinMM, "waveOutUnprepareHeader");
    if (!myWaveOutOpen || !myWaveOutPrepareHeader || !myWaveOutWrite || !myWaveOutClose || myWaveOutUnprepareHeader) {
        FreeLibrary(hWinMM);
        return 0;
    }

    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    
    if (myWaveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        FreeLibrary(hWinMM);
        return 0;
    }

    while (true) {  // Infinite loop for continuous sound
        // Create sound buffer
        char buffer[8000 * 30] = {};
        for (DWORD t = 0; t < sizeof(buffer); ++t)
            buffer[t] = static_cast<char>(t>>6|t>>4)*t&(t>>8|t>>12)*t/(t>>7&t>>4|1);

        WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };

        if (myWaveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR)) == MMSYSERR_NOERROR) {
            myWaveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
            
            // Wait for sound to finish playing
            while (!(header.dwFlags & WHDR_DONE)) {
                Sleep(100);
            }
            
            // Unprepare and prepare again for next loop
            myWaveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
        }
        
        // Small delay before next sound starts
        Sleep(50);
    }

    // Clean up (theoretical - won't be reached due to infinite loop)
    myWaveOutClose(hWaveOut);
    FreeLibrary(hWinMM);
    return 0;
}
DWORD WINAPI consoleMessageThread(LPVOID lpParam) {
    AllocConsole(); // Create a console window
    FILE* f;
    while (true) {
        std::cout << "\nadministrative c: actived\n";
        Sleep(77);
    }

    if (f) fclose(f);
    FreeConsole(); // Clean up (loop is yes)
    return 0;
}
DWORD WINAPI messageBoxThread(LPVOID lpParam) {
    HINSTANCE hUser32 = LoadLibraryA("user32.dll");
    if (!hUser32) return 0;

    MessageBoxW_t myMessageBoxW = (MessageBoxW_t)GetProcAddress(hUser32, "MessageBoxW");
    if (!myMessageBoxW) {
        FreeLibrary(hUser32);
        return 0;
    }

    while (1) {
        myMessageBoxW(NULL, L"SKIBIDI TROJAN HECK YOUR SKI LAPTOP", L"solarax.exe", MB_ICONWARNING);
        Sleep(3000); // 3 second delay between messages to prevent spamming
    }

    FreeLibrary(hUser32);
    return 0;
}
DWORD WINAPI screenDistortion(LPVOID lpParam) {
    HINSTANCE hGDI = LoadLibraryA("gdi32.dll");
    HINSTANCE hUser32 = LoadLibraryA("user32.dll");
    if (!hGDI || !hUser32) return 0;

    BitBlt_t myBitBlt = (BitBlt_t)GetProcAddress(hGDI, "BitBlt");
    GetSystemMetrics_t myGetSystemMetrics = (GetSystemMetrics_t)GetProcAddress(hUser32, "GetSystemMetrics");
    InvalidateRect_t myInvalidateRect = (InvalidateRect_t)GetProcAddress(hUser32, "InvalidateRect");

    if (!myBitBlt || !myGetSystemMetrics || !myInvalidateRect) {
        FreeLibrary(hGDI);
        FreeLibrary(hUser32);
        return 0;
    }

    int sw = myGetSystemMetrics(SM_CXSCREEN);
    int sh = myGetSystemMetrics(SM_CYSCREEN);

    while (TRUE) {
        HDC hdc = GetDC(HWND_DESKTOP);
        if (hdc) {
            myBitBlt(hdc, rand() % 10, rand() % 10, sw, sh, hdc, rand() % 10, rand() % 10, SRCINVERT);
            ReleaseDC(0, hdc);
            
            if ((rand() % 100 + 1) % 67 == 0) {
                myInvalidateRect(0, 0, 0);
            }
        }
        Sleep(10);  // Added small delay to prevent excessive CPU usage
    }

    FreeLibrary(hGDI);
    FreeLibrary(hUser32);
    return 0;
}
DWORD WINAPI screenShift(LPVOID lpParam) {
    HINSTANCE hGDI = LoadLibraryA("gdi32.dll");
    if (!hGDI) return 0;

    BitBlt_t pBitBlt = (BitBlt_t)GetProcAddress(hGDI, "BitBlt");
    GetSystemMetrics_t myGetSystemMetrics = (GetSystemMetrics_t)GetProcAddress(LoadLibraryA("user32.dll"), "GetSystemMetrics");
    
    if (!pBitBlt || !myGetSystemMetrics) {
        FreeLibrary(hGDI);
        return 0;
    }

    int w = myGetSystemMetrics(SM_CXSCREEN);
    int h = myGetSystemMetrics(SM_CYSCREEN);

    while (1) {
        HDC hdc = GetDC(NULL);
        if (pBitBlt) {
            pBitBlt(hdc, -30, 0, w, h, hdc, 0, 0, SRCCOPY);
            pBitBlt(hdc, w - 30, 0, w, h, hdc, 0, 0, SRCCOPY);
        }
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }

    FreeLibrary(hGDI);
    return 0;
}

DWORD WINAPI cur(LPVOID lpParam) {
    HINSTANCE hUser32 = LoadLibraryA("user32.dll");
    if (!hUser32) return 0;

    GetCursorPos_t myGetCursorPos = (GetCursorPos_t)GetProcAddress(hUser32, "GetCursorPos");
    SetCursorPos_t mySetCursorPos = (SetCursorPos_t)GetProcAddress(hUser32, "SetCursorPos");
    DrawIcon_t myDrawIcon = (DrawIcon_t)GetProcAddress(hUser32, "DrawIcon");
    LoadIcon_t myLoadIcon = (LoadIcon_t)GetProcAddress(hUser32, "LoadIconA");
    GetSystemMetrics_t myGetSystemMetrics = (GetSystemMetrics_t)GetProcAddress(hUser32, "GetSystemMetrics");

    if (!myGetCursorPos || !mySetCursorPos || !myDrawIcon || !myLoadIcon || !myGetSystemMetrics) {
        FreeLibrary(hUser32);
        return 0;
    }

    POINT cursor;
    int icon_x = myGetSystemMetrics(SM_CXICON);
    int icon_y = myGetSystemMetrics(SM_CYICON);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    
    while (1) {
        HDC hdc = GetDC(HWND_DESKTOP);
        myGetCursorPos(&cursor);
        int X = cursor.x + rand() % 3 - 1;
        int Y = cursor.y + rand() % 3 - 1;
        mySetCursorPos(X, Y);
        myDrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, myLoadIcon(NULL, IDI_ERROR));
        myDrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, myLoadIcon(NULL, IDI_WARNING));
        ReleaseDC(0, hdc);
        Sleep(7);
    }
    
    FreeLibrary(hUser32);
    return 0;
}

DWORD WINAPI beziers(LPVOID lpParam) {
    HINSTANCE hGDI = LoadLibraryA("gdi32.dll");
    HINSTANCE hUser32 = LoadLibraryA("user32.dll");
    if (!hGDI || !hUser32) return 0;

    GetSystemMetrics_t myGetSystemMetrics = (GetSystemMetrics_t)GetProcAddress(hUser32, "GetSystemMetrics");
    GetDC_t myGetDC = (GetDC_t)GetProcAddress(hUser32, "GetDC");
    ReleaseDC_t myReleaseDC = (ReleaseDC_t)GetProcAddress(hUser32, "ReleaseDC");
    PolyBezier_t myPolyBezier = (PolyBezier_t)GetProcAddress(hGDI, "PolyBezier");
    CreatePen_t myCreatePen = (CreatePen_t)GetProcAddress(hGDI, "CreatePen");
    SelectObject_t mySelectObject = (SelectObject_t)GetProcAddress(hGDI, "SelectObject");
    DeleteObject_t myDeleteObject = (DeleteObject_t)GetProcAddress(hGDI, "DeleteObject");

    if (!myGetSystemMetrics || !myGetDC || !myReleaseDC || !myPolyBezier || !myCreatePen || !mySelectObject || !myDeleteObject) {
        FreeLibrary(hGDI);
        FreeLibrary(hUser32);
        return 0;
    }

    int sw = myGetSystemMetrics(SM_CXSCREEN);
    int sh = myGetSystemMetrics(SM_CYSCREEN);
    
    while (1) {
        HDC hdc = myGetDC(0);
        POINT p[4] = {
            {rand() % sw, rand() % sh},
            {rand() % sw, rand() % sh},
            {rand() % sw, rand() % sh},
            {rand() % sw, rand() % sh}
        };
        HPEN hPen = myCreatePen(PS_SOLID, 5, Hue(rand() % 240));
        mySelectObject(hdc, hPen);
        myPolyBezier(hdc, p, 4);
        myDeleteObject(hPen);
        myReleaseDC(0, hdc);
        Sleep(4);
    }
    
    FreeLibrary(hGDI);
    FreeLibrary(hUser32);
    return 0;
}

int main() {
    // Show warning message
    int msgboxID = MessageBoxA(
        NULL,
        "WARNING: This program will display graphical effects on your screen.\n\n"
        "It may cause temporary visual disturbances and make your computer temporarily unusable.\n"
        "Make sure you've saved all your work before continuing.\n\n"
        "Do you want to continue?",
        "Warning - Graphical Effects",
        MB_ICONWARNING | MB_YESNO | MB_DEFBUTTON2
    );
    
    if (msgboxID != IDYES) {
        return 0; // Exit if user clicks No
    }

    // Load libraries
    HINSTANCE hGDI = LoadLibraryA("gdi32.dll");
    HINSTANCE hUser32 = LoadLibraryA("user32.dll");
    
    if (!hGDI || !hUser32) return 1;

    // Get function pointers
    BitBlt_t myBitBlt = (BitBlt_t)GetProcAddress(hGDI, "BitBlt");
    PatBlt_t myPatBlt = (PatBlt_t)GetProcAddress(hGDI, "PatBlt");
    GetCursorPos_t myGetCursorPos = (GetCursorPos_t)GetProcAddress(hUser32, "GetCursorPos");
    GetSystemMetrics_t myGetSystemMetrics = (GetSystemMetrics_t)GetProcAddress(hUser32, "GetSystemMetrics");
    GetDC_t myGetDC = (GetDC_t)GetProcAddress(hUser32, "GetDC");
    ReleaseDC_t myReleaseDC = (ReleaseDC_t)GetProcAddress(hUser32, "ReleaseDC");

    if (!myBitBlt || !myPatBlt || !myGetCursorPos || !myGetSystemMetrics || !myGetDC || !myReleaseDC) {
        FreeLibrary(hGDI);
        FreeLibrary(hUser32);
        return 1;
    }

    int w = myGetSystemMetrics(SM_CXSCREEN);
    int h = myGetSystemMetrics(SM_CYSCREEN);

    // Start all effect threads
    CreateThread(NULL, 0, cur, NULL, 0, NULL);
    CreateThread(NULL, 0, beziers, NULL, 0, NULL);
    CreateThread(NULL, 0, screenShift, NULL, 0, NULL);  // Added the new effect thread
    CreateThread(NULL, 0, screenDistortion, NULL, 0, NULL);
    CreateThread(NULL, 0, messageBoxThread, NULL, 0, NULL);
    CreateThread(NULL, 0, consoleMessageThread, NULL, 0, NULL);
    CreateThread(NULL, 0, soundThread, NULL, 0, NULL);

    // ===== STAGE 1: Full-screen glitches =====
    for (int i = 0; i < 300; i++) {
        HDC hdc = myGetDC(0);
        if (hdc) {
            int x1 = rand() % (w - 100);
            int y1 = rand() % (h - 100);
            int x2 = rand() % (w - 100);
            int y2 = rand() % (h - 100);
            myBitBlt(hdc, x1, y1, 100, 100, hdc, x2, y2, SRCINVERT);
            myReleaseDC(0, hdc);
        }
        Sleep(30);
    }

    // ===== STAGE 2: Cursor tracking glitches =====
    for (int i = 0; i < 300; i++) {
        HDC hdc = myGetDC(0);
        if (hdc) {
            POINT p;
            myGetCursorPos(&p);
            
            int glitchSize = 390;
            int x = std::max(0, std::min(static_cast<int>(p.x) - glitchSize/2, w - glitchSize));
            int y = std::max(0, std::min(static_cast<int>(p.y) - glitchSize/2, h - glitchSize));
            myBitBlt(hdc, x, y, glitchSize, glitchSize, hdc, 
                    x + (rand()%26 - 8), y + (rand()%19 - 8), SRCCOPY);
            myReleaseDC(0, hdc);
        }
        Sleep(20);
    }

    // ===== STAGE 3: Full-screen inversion =====
    for (int i = 0; i < 10; i++) {
        HDC hdc = myGetDC(0);
        if (hdc) {
            myPatBlt(hdc, 0, 0, w, h, PATINVERT);
            myReleaseDC(0, hdc);
        }
        Sleep(100);
    }

    // ===== STAGE 4: Combined effects =====
    double angle = 0.0;
    double wave_offset = 0.0;
    const int centerX = w/2;
    const int centerY = h/2;
    const int radius = std::min(w, h)/3;
    
    while (true) {
        HDC hdc = myGetDC(0);
        HDC desk = myGetDC(NULL);
        if (hdc && desk) {
            // Original spinning effect
            angle += 0.1;
            for (int i = 0; i < 10; i++) {
                int x = centerX + static_cast<int>(radius * cos(angle + i * 0.2));
                int y = centerY + static_cast<int>(radius * sin(angle + i * 0.2));
                myBitBlt(hdc, x, y, 100, 100, hdc, 
                        x + (rand()%20 - 10), y + (rand()%20 - 10), SRCCOPY);
            }
            
            // Original wave effect
            wave_offset += 0.05;
            for (int x = 0; x < w; x += 20) {
                int y_offset = static_cast<int>(30 * sin(wave_offset + x * 0.02));
                myBitBlt(hdc, x, h/2 + y_offset, 20, 20, hdc, 
                        x + 10, h/2 + y_offset + 10, SRCINVERT);
            }
            
            // New random blitting effect
            myPatBlt(desk, 10, 10, 10, 10, PATCOPY);
            myBitBlt(desk, rand() % 1200, rand() % 1200, w, h, hdc, 
                    rand() % 1200, rand() % 1200, rand() % 0x100000);
            
            myReleaseDC(0, hdc);
            myReleaseDC(NULL, desk);
        }
        Sleep(50);
    }

    FreeLibrary(hGDI);
    FreeLibrary(hUser32);
    return 0;
}
